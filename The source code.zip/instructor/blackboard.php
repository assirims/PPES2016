<?php $page_title = "Instructor Blackboard";?>
<?php require_once("../includes/ins_session.php"); ?>
<?php require_once("../includes/db.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php $_SESSION["re"] = ins_er(); ?>


<?php require_once("../includes/header.php"); ?>
<fieldset>
	<legend>Instructor Blackboard</legend><br />
	<?php
	if(isset($_POST['grd'])){
		ins_er_grd($_POST["ins_cmn"],$_POST["grade"],urldecode($_GET["id"]));
		echo "<div class=\"success\">Your evaluation is recorded.</div><br />";
	}?>
			<input style="width:200px; height:40px;" type="button" onclick="location.href='presentations_evaluations_agent.php';" value="Presentations Evaluations">
			<br /><input style="width:200px; height:40px;" type="button" onclick="location.href='presentations_grad_agent.php';" value="Present. (Grades/Classmates)">
			<hr>
			<hr>
			<input style="width:200px; height:40px;" type="button" onclick="location.href='reviews_evaluations_agent.php';" value="Reviews Evaluations">
			<hr>
			<hr>
			<input style="width:200px; height:40px;" type="button" onclick="location.href='reading_list_agent.php';" value="Reading List">
			<br />
			<input style="width:200px; height:40px;" type="button" onclick="location.href='paper_assignment_agent.php';" value="Paper Assignment">
			<hr>
			<hr>
		<form method="post" action="control.php"><input type="submit" name="logout" style="width:200px; height:40px;" class="del" value="Logout"></form>
</fieldset>
<?php include("../includes/footer.php");?>