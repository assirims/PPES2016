<?php $page_title = "Reviews Reports";?>
<?php require_once("../includes/sessions.php"); ?>
<?php include("../includes/header.php"); ?>
<br />
<fieldset style="width:auto;">
	<legend>Reviews Reports</legend><br />

<?php if(isset($_GET['id'])){
		 if ($_GET['id'] == '1'){
			 $c = $_SESSION["paper1_r"];
		 }elseif($_GET['id'] == '2'){
			 $c = $_SESSION["paper2_r"];
		 }else{
		 	$c = $_SESSION["paper3_r"];
		 }
?>
		<form method="post" action="std_rr.php">
		<br />
		<table BORDER="2" BORDERCOLOR="#09C">
			<tr>
				<th colspan="2">Your Grade</th>
			</tr>
			<tr>
				<td style="width:20%;">Grade:</td>
				<td><?php echo $c["ins_grd"]; ?></td>
			</tr>
			<tr>
				<td>Comments:</td>
				<td style="white-space: normal; width:300px;"><?php echo $c["ins_cmn"]; ?></td>
			</tr>
		</table>
		<br />
		<table BORDER="2" BORDERCOLOR="#09C">
			<tr>
				<th colspan="2">Your Review</th>
			</tr>
			<tr>
				<td>Date and Time:</td>
				<td><?php echo $c["date_time"];?></td>
			</tr>
			<tr>
				<td>Paper:</td>
				<td><?php echo $c["Paper"]; ?></td>
			</tr>
			<tr>
				<td>Technical Correctness</td>
				<td><?php echo $c["technical"]; ?></td>
			</tr>
			<tr>
				<td>Originality</td>
				<td><?php echo $c["originality"]; ?></td>
			</tr>
			<tr>
				<td>Technical Depth</td>
				<td><?php echo $c["depth"]; ?></td>
			</tr>
			<tr>
				<td>Impact/Significance</td>
				<td><?php echo $c["impact"]; ?></td>
			</tr>
			<tr>
				<td>Presentation</td>
				<td><?php echo $c["presentation"]; ?></td>
			</tr>
			<tr>
				<td>Ovarall Rating</td>
				<td><?php echo $c["overall"]; ?></td>
			</tr>
			<tr>
				<td>Summary:</td>
				<td style="white-space: normal; width:300px;"><?php echo htmlentities($c["summary"]); ?></td>
			</tr>
			<tr>
				<td>Strengths</td>
				<td style="white-space: normal; width:300px;"><?php echo htmlentities($c["strengths"]); ?></td>
			</tr>
			<tr>
				<td>Weaknesses</td>
				<td style="white-space: normal; width:300px;"><?php echo htmlentities($c["weaknesses"]); ?></td>
			</tr>
		</table>
		<br />
		<center>
			<br />
			<input type="button" onclick="location.href='reviews_reports_agent.php';" value="Back">
		</center>
		<br />
	</form>
	<?php	}else{?>
	<form method="post" action="std_rr.php">
		<table>
			<tr>
				<td>Reviewer :</td>
				<td><input type="text" name="reviewer" value="<?php echo $_SESSION["pe_agent_ev"];?>"  disabled></td>
			</tr>
			<tr>
				<td>Paper:</td>
				<td>
						<?php
						echo "<a href=\"?id=1\">".$_SESSION["paper1"]."</a>" . "<br />";
						echo "<a href=\"?id=2\">".$_SESSION["paper2"]."</a>" . "<br />";
						echo "<a href=\"?id=3\">".$_SESSION["paper3"]."</a>" . "<br />";						
						?>
				</td>
			</tr>
		</table><br />
		<input type="submit" name="view" value="View">
		<br />
	</form>
	<input type="button" onclick="location.href='blackboard.php';" value="Back"></center>
	
	<?php }?>
	<br />
</fieldset>
<br /><br />
<?php include("../includes/footer.php");?>