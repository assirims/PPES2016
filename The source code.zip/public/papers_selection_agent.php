<?php $page_title = "Paper Selection";?>
<?php require_once("../includes/sessions.php"); ?>
<?php include("../includes/header.php"); ?>
<fieldset style="width:650px;">
	<legend>Paper Selection</legend><br />
	<form method="post" action="blackboard.php">
		<table style="width:650px;">
			  <tr>
			    <th>Title</th>
			    <th>Link</th>
				 <th>Select</th>
			  </tr>
			<?php
			echo $_SESSION["papers"];
			?>
			</table>
			<br />
			<input type="submit" name="select" value="Select">
		</form>
	<br />
</fieldset>
<?php include("../includes/footer.php");?>