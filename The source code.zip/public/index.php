<?php
	header("Location: control.php");
	exit;
?>