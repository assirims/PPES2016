<?php $page_title = "Presentation Report";?>
<?php require_once("../includes/sessions.php"); ?>
<?php include("../includes/header.php"); ?>
<?php $id = $_SESSION["pe_agent_ev"]; ?>
<?php	$c = $_SESSION["pr_agent"]; ?>
<br />
<fieldset>
	<legend>Presentation Report</legend><br />	
		<table BORDER="2" BORDERCOLOR="#09C">
			<tr>
				<th colspan="2">Your Grade</th>
			</tr>
			<tr>
				<td style="width:20%;">Grade:</td>
				<td><?php echo $c["pre_grd"]; ?></td>
			</tr>
			<tr>
				<td>Comments:</td>
				<td style="white-space: normal; width:300px;"><?php echo $c["pre_cmn"]; ?></td>
			</tr>
		</table>
		<br />
		<?php	echo $_SESSION["pr_agent2"];;?>	
		<br />
		<input type="button" onclick="location.href='blackboard.php';" value="Back"></center>
		<br />
</fieldset>
<br />
<?php include("../includes/footer.php");?>