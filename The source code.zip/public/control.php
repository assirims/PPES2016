<?php if(isset($_POST['logout'])){
	session_start();
	$_SESSION = array();
	if (isset($_COOKIE[session_name()])){
		setcookie(session_name(), '', time()-42000, '/');
	}
	session_destroy();
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=control.php">';	
}else{?>
<?php $page_title = "Welcome!";?>
<?php session_start(); ?>
<?php require_once("../includes/db.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/header.php"); ?>
<fieldset>
	<legend>Login</legend>
	<?php 	if (isset($_POST['login'])){
					$required_fields = array("password");
					$numeric_fields = array("student_ID");
					check_numeric_array($numeric_fields);
					check_required_array($required_fields);
					if(empty($validations)){
						if (check_login($_POST["student_ID"], $_POST["password"])){
							$_SESSION["student_id"] = $_POST["student_ID"];
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=blackboard.php">';
						} else {
						    echo  "<div class=\"error\">Student ID or Password does not match.</div>";
						}
					}else{
						echo check_validations($validations);
					}
				}
				 ?>
	<br />
	
		<form name="login_form" method="post" action"control.php">
			Student ID:<input type="text" placeholder="Please enter your student ID" name="student_ID"><br />
    		Password:<input type="password" placeholder="Please enter your password" name="password"><br />
  			<input type="submit" name="login" value="Login"><br />
	 	</form>
		
				
</fieldset>

<?php }?>
<?php include("../includes/footer.php");?>