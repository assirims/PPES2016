<?php $page_title = "Student Blackboard";?>
<?php require_once("../includes/sessions.php"); ?>
<?php require_once("../includes/db.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/header.php"); ?>
<?php $_SESSION["papers"] = papers(); ?>
<?php $_SESSION["pe_agent_pr"] = find_id_pass(find_pre($c)["pre_id"])["name"];?>
<?php $_SESSION["pe_agent_ev"] = find_id_pass($_SESSION['student_id'])["name"];?>
<?php	$_SESSION["pr_agent"] = get_eval(find_id_pass($_SESSION['student_id'])["name"]); ?>
<?php $_SESSION["pr_agent2"] = list_eval(find_id_pass($_SESSION['student_id'])["name"]); ?>
<?php $_SESSION["show_papers"] = show_paper($_SESSION['student_id']);; ?>
<?php $_SESSION["paper1"] = paper_id(1); $_SESSION["paper1_r"] = review($_SESSION["paper1"]); ?>
<?php $_SESSION["paper2"] = paper_id(2); $_SESSION["paper2_r"] = review($_SESSION["paper2"]);?>
<?php $_SESSION["paper3"] = paper_id(3); $_SESSION["paper3_r"] = review($_SESSION["paper3"]);?>





<fieldset>
<legend>Student Blackboard</legend>
<br />
	<?php
	if(isset($_POST['select'])){
		echo "<div class=\"success\">Your selection is submitted.</div><br />";
	}
	?>
	<?php
	if(isset($_POST['pe_agent'])){
		insert_eval($pr,$ev,$_POST['organization2'],$_POST['materials2'],$_POST['ability2'],$_POST['discussion2'],$_POST['knowledge2'],$_POST['comment2']);
		echo "<div class=\"success\">Your evaluation is submitted.</div><br />";
	}
	?>
	<?php
	if(isset($_POST['submit_review'])){
		$reviewer = mysqli_real_escape_string($connection, $_POST['name2']);
		$Paper = mysqli_real_escape_string($connection, $_POST['papers2']);
		$technical = mysqli_real_escape_string($connection, $_POST['correctness2']);
		$originality = mysqli_real_escape_string($connection, $_POST['originality2']);
		$depth = mysqli_real_escape_string($connection, $_POST['depth2']);
		$impact = mysqli_real_escape_string($connection, $_POST['impact2']);
		$presentation = mysqli_real_escape_string($connection, $_POST['presentation2']);
		$overall = mysqli_real_escape_string($connection, $_POST['rating2']);
		$summary = mysqli_real_escape_string($connection, $_POST['comment2']);
		$strengths = mysqli_real_escape_string($connection, $_POST['strengths2']);
		$weaknesses = mysqli_real_escape_string($connection, $_POST['weaknesses2']);
	
	sumbit_review($reviewer,$Paper,$technical,$originality,$depth,$impact,$presentation,$overall,$summary,$strengths,$weaknesses);
	
	echo "<div class=\"success\">Your review is submitted.</div><br />";
	
	}
	?>
	<input style="width:200px; height:40px;" type="button" onclick="location.href='papers_selection_agent.php';" value="Papers Selection">
	<hr /><hr />
	<input style="width:200px; height:40px;" type="button" onclick="location.href='presentation_evaluations_agent.php';" value="Presentation Evaluations"><br />
	<input style="width:200px; height:40px;" type="button" onclick="location.href='presentation_report_agent.php';" value="Presentation Report">
	<hr /><hr />
	<input style="width:200px; height:40px;" type="button" onclick="location.href='review_submission_agent.php';" value="Review Submission"><br />
	<input style="width:200px; height:40px;" type="button" onclick="location.href='reviews_reports_agent.php';" value="Reviews Reports">
	<hr /><hr />	
	<form method="post" action="control.php"><input type="submit" name="logout" style="width:200px; height:40px;" class="del" value="Logout"></form><br />
</fieldset>
<?php include("../includes/footer.php");?>